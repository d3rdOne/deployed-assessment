export enum FormMode {
  NEW,
  EDIT
}