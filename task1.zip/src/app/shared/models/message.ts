export interface Message {
  id: number;
  title: string,
  body: string,
  dateCreated: string
}

export interface MessageForm {
  title: string,
  body: string,
}